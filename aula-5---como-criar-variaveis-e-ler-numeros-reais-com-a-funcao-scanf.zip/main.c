/******************************************************************************

Welcome to GDB Online.
  GDB online is an online compiler and debugger tool for C, C++, Python, PHP, Ruby, 
  C#, OCaml, VB, Perl, Swift, Prolog, Javascript, Pascal, COBOL, HTML, CSS, JS
  Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include <stdio.h>

int main(){
    
    // tipo nome;
    float numero = 3.1415;
    
    printf("Valor da minha variavel: %.4f\n", numero);
    
    printf("Digite um numero real: ");
    scanf("%f", &numero);
    
    printf("Valor lido: %.3f\n", numero);
    // 
    // int valor, valor2;
    
    // valor = 50;
    
    // printf("Digite um valor inteiro: ");
    // scanf("%d", &valor);
    
    // printf("Digite um segundo valor inteiro: ");
    // scanf("%d", &valor2);
    
    // printf("\n\nValor da minha variavel: %d\nSegundo valor: %d\n\n", valor, valor2);
    // 
    return 0;
}