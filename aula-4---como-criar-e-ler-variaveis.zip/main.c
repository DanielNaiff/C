#include <stdio.h>

int main(){
    
    int valor, valor2;
    
    valor = 50;
    
    printf("Digite um valor inteiro: ");
    scanf("%d", &valor);
    
    printf("Digite um segundo valor inteiro: ");
    scanf("%d", &valor2);
    
    printf("\n\nValor da minha variavel: %d\nSegundo valor: %d\n\n", valor, valor2);
    
    return 0;
}